


import '../state/quiz.dart';

class QuizCategory{
  final List<Quiz> section;

  QuizCategory(this.section);
}